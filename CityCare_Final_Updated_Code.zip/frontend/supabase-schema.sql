-- ═══════════════════════════════════════════════════════════════
-- CityCare Health Hospital — Supabase Database Schema
-- Run this in: Supabase Dashboard → SQL Editor → New Query
-- ═══════════════════════════════════════════════════════════════

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ──────────────────────────────────────────
-- TABLE: hospitals
-- ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS hospitals (
  id              BIGSERIAL PRIMARY KEY,
  name            TEXT NOT NULL,
  code            TEXT NOT NULL UNIQUE,
  address         TEXT,
  city            TEXT,
  phone           TEXT,
  operating_hours TEXT,
  latitude        FLOAT DEFAULT 0,
  longitude       FLOAT DEFAULT 0,
  specifications  TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Seed default hospitals
INSERT INTO hospitals (name, code, address, city, phone, operating_hours, latitude, longitude, specifications)
VALUES
  ('Sakthi Hospital', 'SH-01', '45 GST Road, Guindy', 'Chennai', '+91 44 2888-5555',
   '24/7 Multi-Specialty & Trauma', 13.0067, 80.2025,
   'Level-1 Trauma Center, 500 Inpatient Beds, 3T Digital MRI, 128-Slice Cardiac CT, Robotic Joint Replacement Unit, 50-Bed Dedicated ICU, 24/7 Emergency Cath Lab, Cardiology, Orthopedics'),
  ('CityCare Health Hospital', 'CCH-MAIN', '100 Healthcare Parkway, Metro Center', 'New York', '+1 555-0100',
   '24/7 Emergency & Inpatient', 40.7128, -74.0060,
   'NABH Accredited, Level-1 Trauma Care, 450 Inpatient Beds, 64-Slice Cardiac CT, 24/7 Emergency Cath Lab, Multi-Organ Transplant Center, Neurology'),
  ('Apollo Multispecialty Care', 'APL-02', '21 Greams Lane, Thousand Lights', 'Chennai', '+91 44 2829-0200',
   '24/7 Emergency & Outpatient', 13.0604, 80.2496,
   'JCI Accredited, 600 Beds, DaVinci Robotic Surgery, PET-CT Diagnostic Suite, Comprehensive Stroke Center, 70 ICU & Neonatal Beds, Oncology')
ON CONFLICT (code) DO NOTHING;

-- ──────────────────────────────────────────
-- TABLE: doctors
-- ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS doctors (
  id                BIGSERIAL PRIMARY KEY,
  name              TEXT NOT NULL,
  email             TEXT,
  phone             TEXT,
  qualification     TEXT,
  specialization    TEXT,
  experience_years  INT DEFAULT 0,
  consultation_fee  INT DEFAULT 0,
  available_days    TEXT,
  available_time    TEXT,
  slots             TEXT[],
  department_name   TEXT,
  hospital_name     TEXT,
  bio               TEXT,
  image             TEXT,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Seed default doctors
INSERT INTO doctors (name, email, phone, qualification, specialization, experience_years, consultation_fee, available_days, available_time, slots, department_name, hospital_name, bio, image)
VALUES
  ('Dr. Sarah Jenkins', 'sarah.jenkins@citycarehealth.com', '+1 555-0101',
   'MD, FACC, FSCAI', 'Senior Interventional Cardiologist', 15, 120,
   'Mon, Wed, Fri', '09:00 AM - 01:00 PM',
   ARRAY['09:00 AM','10:30 AM','02:00 PM','04:30 PM'], 'Cardiology', 'Sakthi Hospital',
   'Dr. Jenkins has performed over 3,000 successful coronary angioplasties.',
   'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=400'),
  ('Dr. Marcus Vance', 'marcus.vance@citycarehealth.com', '+1 555-0103',
   'MD, PhD (Neuroscience)', 'Head of Neurological Sciences', 18, 150,
   'Mon, Tue, Thu', '09:30 AM - 02:30 PM',
   ARRAY['09:30 AM','11:00 AM','01:00 PM'], 'Neurology & Neurosurgery', 'CityCare Health Hospital',
   'Expert in stroke management, epilepsy, and neurodegenerative diseases.',
   'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=400'),
  ('Dr. Elena Rostova', 'elena.rostova@citycarehealth.com', '+1 555-0104',
   'MS (Ortho), MCh (Joint Replacement)', 'Senior Orthopedic & Spine Surgeon', 14, 130,
   'Mon, Wed, Fri', '08:30 AM - 01:30 PM',
   ARRAY['08:30 AM','10:00 AM','12:00 PM'], 'Orthopedics & Joint Care', 'Sakthi Hospital',
   'Specialist in robotic knee and hip replacement surgeries.',
   'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&q=80&w=400'),
  ('Dr. David Miller', 'david.miller@citycarehealth.com', '+1 555-0105',
   'MBBS, MD (Internal Medicine)', 'Chief Consultant Physician', 20, 100,
   'Mon-Sat', '01:00 PM - 05:00 PM',
   ARRAY['01:00 PM','02:30 PM','04:00 PM'], 'General Internal Medicine', 'Apollo Multispecialty Care',
   'Experienced in preventive care, chronic disease management.',
   'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=400')
ON CONFLICT DO NOTHING;

-- ──────────────────────────────────────────
-- TABLE: appointments
-- ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS appointments (
  id                  BIGSERIAL PRIMARY KEY,
  appointment_code    TEXT UNIQUE NOT NULL,
  patient_name        TEXT,
  patient_email       TEXT,
  patient_phone       TEXT,
  patient_age         INT,
  patient_gender      TEXT,
  hospital_name       TEXT,
  doctor_id           INT,
  doctor_name         TEXT,
  specialization      TEXT,
  department_name     TEXT,
  appointment_date    TEXT,
  appointment_time    TEXT,
  symptoms            TEXT,
  body_issues         TEXT,
  booking_type        TEXT DEFAULT 'REGULAR',
  patient_command     TEXT,
  status              TEXT DEFAULT 'CONFIRMED',
  check_in_status     TEXT DEFAULT 'NOT_CHECKED_IN',
  checked_in_at       TEXT,
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ──────────────────────────────────────────
-- TABLE: seat_allocations
-- ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS seat_allocations (
  id                    BIGSERIAL PRIMARY KEY,
  hospital_name         TEXT,
  doctor_name           TEXT,
  specialization        TEXT,
  department_name       TEXT,
  room_number           TEXT,
  session_name          TEXT,
  session_date          TEXT DEFAULT CURRENT_DATE::TEXT,
  total_seats           INT DEFAULT 30,
  booked_seats          INT DEFAULT 0,
  current_token_number  INT DEFAULT 0,
  session_status        TEXT DEFAULT 'STARTING_SOON',
  updated_at            TIMESTAMPTZ DEFAULT NOW()
);

-- Seed live sessions
INSERT INTO seat_allocations (hospital_name, doctor_name, specialization, department_name, room_number, session_name, total_seats, booked_seats, current_token_number, session_status)
VALUES
  ('Sakthi Hospital', 'Dr. Elena Rostova', 'Senior Orthopedic & Spine Surgeon', 'Orthopedics & Joint Care',
   'OPD Room 101, Joint Care Wing', 'Morning OPD (08:30 AM - 01:30 PM)', 25, 18, 9, 'IN_PROGRESS'),
  ('Sakthi Hospital', 'Dr. Sarah Jenkins', 'Senior Interventional Cardiologist', 'Cardiology',
   'Room 103, Heart Wing', 'Morning OPD (09:00 AM - 01:00 PM)', 30, 22, 14, 'IN_PROGRESS'),
  ('CityCare Health Hospital', 'Dr. Marcus Vance', 'Head of Neurological Sciences', 'Neurology & Neurosurgery',
   'Room 204, Neuro OPD', 'Morning OPD (09:30 AM - 02:30 PM)', 20, 15, 7, 'IN_PROGRESS'),
  ('Apollo Multispecialty Care', 'Dr. David Miller', 'Chief Consultant Physician', 'General Internal Medicine',
   'Room 305, Executive OPD', 'Afternoon OPD (01:00 PM - 05:00 PM)', 25, 10, 1, 'STARTING_SOON')
ON CONFLICT DO NOTHING;

-- ──────────────────────────────────────────
-- Row Level Security (RLS)
-- ──────────────────────────────────────────
ALTER TABLE hospitals       ENABLE ROW LEVEL SECURITY;
ALTER TABLE doctors         ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments    ENABLE ROW LEVEL SECURITY;
ALTER TABLE seat_allocations ENABLE ROW LEVEL SECURITY;

-- Allow public read on hospitals, doctors, seat_allocations
CREATE POLICY "Public read hospitals"        ON hospitals        FOR SELECT USING (true);
CREATE POLICY "Public read doctors"          ON doctors          FOR SELECT USING (true);
CREATE POLICY "Public read seats"            ON seat_allocations FOR SELECT USING (true);
CREATE POLICY "Public insert appointments"   ON appointments     FOR INSERT WITH CHECK (true);
CREATE POLICY "Public read appointments"     ON appointments     FOR SELECT USING (true);

-- Allow anon to do full CRUD (for admin dashboard via anon key)
CREATE POLICY "Anon full hospitals"          ON hospitals        FOR ALL  USING (true) WITH CHECK (true);
CREATE POLICY "Anon full doctors"            ON doctors          FOR ALL  USING (true) WITH CHECK (true);
CREATE POLICY "Anon full seats"              ON seat_allocations FOR ALL  USING (true) WITH CHECK (true);
CREATE POLICY "Anon full appointments"       ON appointments     FOR ALL  USING (true) WITH CHECK (true);

-- ──────────────────────────────────────────
-- Realtime
-- ──────────────────────────────────────────
ALTER PUBLICATION supabase_realtime ADD TABLE seat_allocations;
ALTER PUBLICATION supabase_realtime ADD TABLE appointments;

SELECT 'Schema created successfully! Now update js/supabase-config.js with your URL and key.' AS result;
