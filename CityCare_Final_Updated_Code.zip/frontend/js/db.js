// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CityCare Health — Database Layer  (Supabase + localStorage fallback)
// Fixed: PATCH 204 No Content, clean payloads, camelCase normalization
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const DB = (() => {

  // ── Core REST helper ─────────────────────────────────────────────────────────
  async function sbFetch(path, method, body, params) {
    method = method || 'GET';
    params = params || '';
    if (!SUPABASE_ENABLED || !SUPABASE_URL || SUPABASE_URL.includes('YOUR_')) return null;
    const url = SUPABASE_URL + '/rest/v1/' + path + (params ? '?' + params : '');
    const opts = {
      method: method,
      headers: {
        'apikey':        SUPABASE_ANON,
        'Authorization': 'Bearer ' + SUPABASE_ANON,
        'Content-Type':  'application/json',
        'Prefer':        method === 'POST' ? 'return=representation' : 'return=minimal'
      }
    };
    if (body) opts.body = JSON.stringify(body);
    try {
      const res = await fetch(url, opts);
      if (!res.ok) {
        const errText = await res.text();
        console.warn('[DB] ' + method + ' ' + path + ' => ' + res.status, errText);
        return null;
      }
      // PATCH / DELETE return 204 No Content — do NOT parse body
      if (method === 'PATCH' || method === 'DELETE') return true;
      const text = await res.text();
      return text ? JSON.parse(text) : true;
    } catch (e) {
      console.warn('[DB] fetch failed:', e.message);
      return null;
    }
  }

  // ── Clean payload: only snake_case columns Supabase knows about ──────────────
  function toSbHospital(h) {
    return {
      name:            h.name            || '',
      code:            h.code            || '',
      address:         h.address         || '',
      city:            h.city            || '',
      phone:           h.phone           || '',
      operating_hours: h.operating_hours || h.operatingHours || '',
      latitude:        parseFloat(h.latitude)  || 0,
      longitude:       parseFloat(h.longitude) || 0,
      specifications:  h.specifications  || ''
    };
  }

  function toSbDoctor(d) {
    return {
      name:             d.name             || '',
      email:            d.email            || '',
      phone:            d.phone            || '',
      qualification:    d.qualification    || '',
      specialization:   d.specialization   || '',
      experience_years: parseInt(d.experience_years || d.experienceYears) || 0,
      consultation_fee: parseInt(d.consultation_fee || d.consultationFee) || 0,
      available_days:   d.available_days   || d.availableDays   || '',
      available_time:   d.available_time   || d.availableTime   || '',
      slots:            Array.isArray(d.slots) ? d.slots : [],
      department_name:  d.department_name  || d.departmentName  || '',
      hospital_name:    d.hospital_name    || d.hospitalName    || '',
      bio:              d.bio              || '',
      image:            d.image            || ''
    };
  }

  function toSbSeat(s) {
    return {
      hospital_name:        s.hospital_name        || s.hospitalName        || '',
      doctor_name:          s.doctor_name           || s.doctorName          || '',
      specialization:       s.specialization        || '',
      department_name:      s.department_name       || s.departmentName      || '',
      room_number:          s.room_number            || s.roomNumber          || '',
      session_name:         s.session_name           || s.sessionName         || '',
      session_date:         s.session_date           || s.sessionDate         || new Date().toISOString().split('T')[0],
      total_seats:          parseInt(s.total_seats           || s.totalSeats)          || 30,
      booked_seats:         parseInt(s.booked_seats          || s.bookedSeats)         || 0,
      current_token_number: parseInt(s.current_token_number  || s.currentTokenNumber)  || 0,
      session_status:       s.session_status         || s.sessionStatus       || 'STARTING_SOON'
    };
  }

  function toSbAppointment(a) {
    return {
      appointment_code: a.appointmentCode || a.appointment_code || '',
      patient_name:     a.patientName     || a.patient_name     || '',
      patient_email:    a.patientEmail    || a.patient_email    || '',
      patient_phone:    a.patientPhone    || a.patient_phone    || '',
      patient_age:      parseInt(a.patientAge || a.patient_age) || 0,
      patient_gender:   a.patientGender   || a.patient_gender   || '',
      hospital_name:    a.hospitalName    || a.hospital_name    || '',
      doctor_id:        a.doctorId        || a.doctor_id        || null,
      doctor_name:      a.doctorName      || a.doctor_name      || '',
      specialization:   a.specialization  || '',
      department_name:  a.departmentName  || a.department_name  || '',
      appointment_date: a.appointmentDate || a.appointment_date || '',
      appointment_time: a.appointmentTime || a.appointment_time || '',
      symptoms:         a.symptoms        || '',
      body_issues:      a.bodyIssues      || a.body_issues      || '',
      booking_type:     a.bookingType     || a.booking_type     || 'REGULAR',
      patient_command:  a.patientCommand  || a.patient_command  || '',
      status:           a.status          || 'CONFIRMED',
      check_in_status:  a.checkInStatus   || a.check_in_status  || 'NOT_CHECKED_IN'
    };
  }

  // ── Normalize Supabase rows → add camelCase aliases for public pages ──────────
  function nhospital(h) {
    h.operatingHours = h.operating_hours;
    return h;
  }

  function ndoctor(d) {
    d.departmentName  = d.department_name;
    d.hospitalName    = d.hospital_name;
    d.experienceYears = d.experience_years;
    d.consultationFee = d.consultation_fee;
    d.availableDays   = d.available_days;
    d.availableTime   = d.available_time;
    if (!Array.isArray(d.slots)) {
      try { d.slots = typeof d.slots === 'string' ? JSON.parse(d.slots) : []; } catch(e) { d.slots = []; }
    }
    return d;
  }

  function nseat(s) {
    s.hospitalName       = s.hospital_name;
    s.doctorName         = s.doctor_name;
    s.departmentName     = s.department_name;
    s.roomNumber         = s.room_number;
    s.sessionName        = s.session_name;
    s.totalSeats         = s.total_seats;
    s.bookedSeats        = s.booked_seats;
    s.currentTokenNumber = s.current_token_number;
    s.sessionStatus      = s.session_status;
    s.updatedAt          = s.updated_at;
    return s;
  }

  function nappt(a) {
    a.appointmentCode = a.appointment_code;
    a.patientName     = a.patient_name;
    a.patientPhone    = a.patient_phone;
    a.patientEmail    = a.patient_email;
    a.patientAge      = a.patient_age;
    a.patientGender   = a.patient_gender;
    a.hospitalName    = a.hospital_name;
    a.doctorName      = a.doctor_name;
    a.departmentName  = a.department_name;
    a.appointmentDate = a.appointment_date;
    a.appointmentTime = a.appointment_time;
    a.bodyIssues      = a.body_issues;
    a.bookingType     = a.booking_type;
    a.patientCommand  = a.patient_command;
    a.checkInStatus   = a.check_in_status;
    a.checkedInAt     = a.checked_in_at;
    return a;
  }

  // ── HOSPITALS ────────────────────────────────────────────────────────────────
  async function getHospitals() {
    const rows = await sbFetch('hospitals', 'GET', null, 'order=id.asc');
    if (Array.isArray(rows)) {
      const list = rows.map(nhospital);
      localStorage.setItem('citycare_hospitals', JSON.stringify(list));
      return list;
    }
    return CityCareData.getHospitals();
  }

  async function saveHospital(h) {
    const payload = toSbHospital(h);
    let ok = false;
    if (h.id) {
      ok = await sbFetch('hospitals?id=eq.' + h.id, 'PATCH', payload);
    } else {
      const rows = await sbFetch('hospitals', 'POST', payload);
      ok = Array.isArray(rows) && rows.length > 0;
    }
    if (ok) return getHospitals();
    CityCareData.saveHospital(h);
    return getHospitals();
  }

  async function deleteHospital(id) {
    const ok = await sbFetch('hospitals?id=eq.' + id, 'DELETE');
    if (ok) return getHospitals();
    const list = CityCareData.getHospitals().filter(x => x.id != id);
    localStorage.setItem('citycare_hospitals', JSON.stringify(list));
    return list;
  }

  // ── DOCTORS ──────────────────────────────────────────────────────────────────
  async function getDoctors() {
    const rows = await sbFetch('doctors', 'GET', null, 'order=id.asc');
    if (Array.isArray(rows)) {
      const list = rows.map(ndoctor);
      localStorage.setItem('citycare_doctors', JSON.stringify(list));
      return list;
    }
    return CityCareData.getDoctors();
  }

  async function saveDoctor(d) {
    const payload = toSbDoctor(d);
    let ok = false;
    if (d.id) {
      ok = await sbFetch('doctors?id=eq.' + d.id, 'PATCH', payload);
    } else {
      const rows = await sbFetch('doctors', 'POST', payload);
      ok = Array.isArray(rows) && rows.length > 0;
    }
    if (ok) return getDoctors();
    CityCareData.saveDoctor(d);
    return getDoctors();
  }

  async function deleteDoctor(id) {
    const ok = await sbFetch('doctors?id=eq.' + id, 'DELETE');
    if (ok) return getDoctors();
    CityCareData.deleteDoctor(id);
    return getDoctors();
  }

  // ── APPOINTMENTS ─────────────────────────────────────────────────────────────
  async function getAppointments() {
    const rows = await sbFetch('appointments', 'GET', null, 'order=created_at.desc');
    if (Array.isArray(rows)) {
      const list = rows.map(nappt);
      localStorage.setItem('citycare_appointments', JSON.stringify(list));
      return list;
    }
    return CityCareData.getAppointments();
  }

  async function saveAppointment(apt) {
    const payload = toSbAppointment(apt);
    const rows = await sbFetch('appointments', 'POST', payload);
    if (Array.isArray(rows) && rows.length) return nappt(rows[0]);
    return CityCareData.saveAppointment(apt);
  }

  async function findAppointment(query) {
    if (!query) return null;
    const q = query.trim().toUpperCase();
    const byCode = await sbFetch('appointments', 'GET', null,
      'appointment_code=eq.' + encodeURIComponent(q) + '&limit=1');
    if (Array.isArray(byCode) && byCode.length) return nappt(byCode[0]);
    const digits = q.replace(/\D/g, '');
    if (digits) {
      const byPhone = await sbFetch('appointments', 'GET', null,
        'patient_phone=ilike.*' + encodeURIComponent(digits) + '*&limit=1');
      if (Array.isArray(byPhone) && byPhone.length) return nappt(byPhone[0]);
    }
    return CityCareData.findAppointment(query);
  }

  async function checkInAppointment(code) {
    if (!code) return null;
    const c = code.trim().toUpperCase();
    const ok = await sbFetch('appointments?appointment_code=eq.' + encodeURIComponent(c), 'PATCH',
      { check_in_status: 'CHECKED_IN', checked_in_at: new Date().toLocaleString() });
    if (ok) {
      const rows = await sbFetch('appointments', 'GET', null, 'appointment_code=eq.' + encodeURIComponent(c));
      return Array.isArray(rows) && rows.length ? nappt(rows[0]) : null;
    }
    return CityCareData.checkInAppointment ? CityCareData.checkInAppointment(code) : null;
  }

  async function cancelAppointment(code) {
    if (!code) return null;
    const c = code.trim().toUpperCase();
    const ok = await sbFetch('appointments?appointment_code=eq.' + encodeURIComponent(c), 'PATCH', { status: 'CANCELLED' });
    if (ok) return { status: 'CANCELLED', appointmentCode: code };
    return CityCareData.cancelAppointment ? CityCareData.cancelAppointment(code) : null;
  }

  // ── SEAT ALLOCATIONS ─────────────────────────────────────────────────────────
  async function getSeatAllocations(hospitalFilter) {
    let params = 'order=id.asc';
    if (hospitalFilter) params += '&hospital_name=eq.' + encodeURIComponent(hospitalFilter);
    const rows = await sbFetch('seat_allocations', 'GET', null, params);
    if (Array.isArray(rows)) {
      const list = rows.map(nseat);
      localStorage.setItem('citycare_seat_allocations', JSON.stringify(list));
      return list;
    }
    return CityCareData.getSeatAllocations();
  }

  async function saveSeatAllocation(s) {
    const payload = toSbSeat(s);
    let ok = false;
    if (s.id && !String(s.id).startsWith('ts_')) {
      ok = await sbFetch('seat_allocations?id=eq.' + s.id, 'PATCH', payload);
    } else {
      const rows = await sbFetch('seat_allocations', 'POST', payload);
      ok = Array.isArray(rows) && rows.length > 0;
    }
    if (ok) return getSeatAllocations();
    // localStorage fallback
    const list = CityCareData.getSeatAllocations();
    s.id = 'ts_' + Date.now();
    list.push(s);
    localStorage.setItem('citycare_seat_allocations', JSON.stringify(list));
    return list;
  }

  async function updateSeatAllocation(id, totalSeats, bookedSeats, currentToken, status, room) {
    const payload = {
      total_seats:          parseInt(totalSeats),
      booked_seats:         parseInt(bookedSeats),
      current_token_number: parseInt(currentToken),
      session_status:       status,
      room_number:          room,
      updated_at:           new Date().toISOString()
    };
    const ok = await sbFetch('seat_allocations?id=eq.' + id, 'PATCH', payload);
    if (ok) return getSeatAllocations();
    return CityCareData.updateSeatAllocation(id, totalSeats, bookedSeats, currentToken, status, room);
  }

  async function deleteSeatAllocation(id) {
    const ok = await sbFetch('seat_allocations?id=eq.' + id, 'DELETE');
    if (ok) return getSeatAllocations();
    const list = CityCareData.getSeatAllocations().filter(x => x.id != id);
    localStorage.setItem('citycare_seat_allocations', JSON.stringify(list));
    return list;
  }

  // ── Public API ────────────────────────────────────────────────────────────────
  return {
    getHospitals, saveHospital, deleteHospital,
    getDoctors, saveDoctor, deleteDoctor,
    getAppointments, saveAppointment, findAppointment, checkInAppointment, cancelAppointment,
    getSeatAllocations, saveSeatAllocation, updateSeatAllocation, deleteSeatAllocation
  };
})();
