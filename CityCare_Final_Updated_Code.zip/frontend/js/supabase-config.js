// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CityCare Health — Supabase Configuration
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Steps:
//  1. Go to https://supabase.com → New Project
//  2. Settings → API → copy Project URL and anon key below
//  3. Go to SQL Editor → run the schema from supabase-schema.sql
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const SUPABASE_URL  = 'https://lwsrwsmckuumfascaqtr.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx3c3J3c21ja3V1bWZhc2NhcXRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk0NzE3MzEsImV4cCI6MjEwNTA0NzczMX0.oVebWV6cJyWd33W0RpYW0XXWOrocbgsKq5_I1hFcndU';

// Supabase is now active — all data syncs to the cloud database
const SUPABASE_ENABLED = true;
