// CityCare Health - Client Side Interactions & Geolocation Engine

// 1. Geolocation Function for "1. Detect Location"
function detectLocation() {
    if (!navigator.geolocation) {
        alert("Location permission is required to find nearby hospitals.");
        return;
    }

    const detectBtn = document.getElementById('detectLocationBtn');
    const originalContent = detectBtn ? detectBtn.innerHTML : '';
    if (detectBtn) {
        detectBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i> Detecting GPS Location...';
        detectBtn.disabled = true;
    }

    navigator.geolocation.getCurrentPosition(
        function (position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            // Open Google Maps search in new tab with dynamic coordinates
            const mapsUrl = `https://www.google.com/maps/search/hospitals/@${lat},${lng},14z`;
            window.open(mapsUrl, '_blank');
            if (detectBtn) {
                detectBtn.innerHTML = originalContent;
                detectBtn.disabled = false;
            }
        },
        function (error) {
            if (detectBtn) {
                detectBtn.innerHTML = originalContent;
                detectBtn.disabled = false;
            }
            alert("Location permission is required to find nearby hospitals.");
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }
    );
}

// Print Receipt Helper
function printPass() {
    window.print();
}

document.addEventListener('DOMContentLoaded', function () {
    // Auto-dismiss alerts
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 6000);
    });

    // Date picker min constraint
    const dateInput = document.getElementById('appointmentDate');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.setAttribute('min', today);
    }
});
