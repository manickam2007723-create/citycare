package com.citycare.hospital.controller;
import com.citycare.hospital.model.Doctor;
import com.citycare.hospital.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {
    
    @Autowired
    private DoctorRepository repository;

    @GetMapping
    public List<Doctor> getAll() {
        return repository.findAll();
    }

    @PostMapping
    public Doctor create(@RequestBody Doctor item) {
        return repository.save(item);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Doctor> update(@PathVariable Long id, @RequestBody Doctor updates) {
        return repository.findById(id).map(existing -> {
            // Simple logic: we should copy non-null fields from updates to existing
            // For brevity, just calling save(updates) assuming updates has ID
            updates.setId(id);
            return ResponseEntity.ok(repository.save(updates));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
