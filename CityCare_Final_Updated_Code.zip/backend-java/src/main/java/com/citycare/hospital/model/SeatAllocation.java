package com.citycare.hospital.model;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "seat_allocations")
@Data
public class SeatAllocation {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String hospitalName;
    private String sessionName;
    private String room;
    private String date;
    private Integer totalSeats;
    private Integer allocatedSeats;
    private Integer currentToken;
    private String status;
    private String departmentName;
    private String doctorName;
}
