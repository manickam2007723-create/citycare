package com.citycare.hospital.repository;
import com.citycare.hospital.model.SeatAllocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SeatAllocationRepository extends JpaRepository<SeatAllocation, Long> {
}
