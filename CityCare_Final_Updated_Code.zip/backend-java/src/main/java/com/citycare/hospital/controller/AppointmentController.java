package com.citycare.hospital.controller;
import com.citycare.hospital.model.Appointment;
import com.citycare.hospital.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {
    
    @Autowired
    private AppointmentRepository repository;

    @GetMapping
    public List<Appointment> getAll() {
        return repository.findAll();
    }

    @PostMapping
    public Appointment create(@RequestBody Appointment item) {
        return repository.save(item);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Appointment> update(@PathVariable Long id, @RequestBody Appointment updates) {
        return repository.findById(id).map(existing -> {
            // Simple logic: we should copy non-null fields from updates to existing
            // For brevity, just calling save(updates) assuming updates has ID
            updates.setId(id);
            return ResponseEntity.ok(repository.save(updates));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public ResponseEntity<Appointment> getByCode(@RequestParam String code) {
        Appointment apt = repository.findByAppointmentCode(code);
        return apt != null ? ResponseEntity.ok(apt) : ResponseEntity.notFound().build();
    }
}
