package com.citycare.hospital.model;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "hospitals")
@Data
public class Hospital {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String address;
    private String city;
    private String phone;
    private String operatingHours;
    private Double latitude;
    private Double longitude;
    @Column(columnDefinition="TEXT")
    private String specifications;
    private Integer activeBeds;
    private Integer emergencyBeds;
}
