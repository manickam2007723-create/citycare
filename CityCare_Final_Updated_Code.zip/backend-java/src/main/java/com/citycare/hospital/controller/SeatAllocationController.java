package com.citycare.hospital.controller;
import com.citycare.hospital.model.SeatAllocation;
import com.citycare.hospital.repository.SeatAllocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/seat_allocations")
public class SeatAllocationController {
    
    @Autowired
    private SeatAllocationRepository repository;

    @GetMapping
    public List<SeatAllocation> getAll() {
        return repository.findAll();
    }

    @PostMapping
    public SeatAllocation create(@RequestBody SeatAllocation item) {
        return repository.save(item);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<SeatAllocation> update(@PathVariable Long id, @RequestBody SeatAllocation updates) {
        return repository.findById(id).map(existing -> {
            // Simple logic: we should copy non-null fields from updates to existing
            // For brevity, just calling save(updates) assuming updates has ID
            updates.setId(id);
            return ResponseEntity.ok(repository.save(updates));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
