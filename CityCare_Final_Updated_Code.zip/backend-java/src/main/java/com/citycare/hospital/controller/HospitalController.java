package com.citycare.hospital.controller;
import com.citycare.hospital.model.Hospital;
import com.citycare.hospital.repository.HospitalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/hospitals")
public class HospitalController {
    
    @Autowired
    private HospitalRepository repository;

    @GetMapping
    public List<Hospital> getAll() {
        return repository.findAll();
    }

    @PostMapping
    public Hospital create(@RequestBody Hospital item) {
        return repository.save(item);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Hospital> update(@PathVariable Long id, @RequestBody Hospital updates) {
        return repository.findById(id).map(existing -> {
            // Simple logic: we should copy non-null fields from updates to existing
            // For brevity, just calling save(updates) assuming updates has ID
            updates.setId(id);
            return ResponseEntity.ok(repository.save(updates));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
