package com.citycare.hospital.model;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "doctors")
@Data
public class Doctor {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String phone;
    private String qualification;
    private String specialization;
    private Integer experienceYears;
    private Double consultationFee;
    private String availableDays;
    private String availableTime;
    @Column(columnDefinition="TEXT")
    private String slots;
    private String hospitalName;
    private String departmentName;
}
