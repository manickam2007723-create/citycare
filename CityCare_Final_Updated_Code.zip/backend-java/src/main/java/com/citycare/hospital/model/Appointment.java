package com.citycare.hospital.model;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "appointments")
@Data
public class Appointment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String appointmentCode;
    private String patientName;
    private String patientEmail;
    private String patientPhone;
    private Integer patientAge;
    private String patientGender;
    private String hospitalName;
    private Long doctorId;
    private String doctorName;
    private String specialization;
    private String departmentId;
    private String departmentName;
    private String appointmentDate;
    private String appointmentTime;
    private String bookingType;
    @Column(columnDefinition="TEXT")
    private String bodyIssues;
    @Column(columnDefinition="TEXT")
    private String patientCommand;
    @Column(columnDefinition="TEXT")
    private String symptoms;
    private String status;
    private String checkInStatus;
    private String checkedInAt;
    private String createdAt;
}
